<?php

    class Signup{
       
        private $error = "";
        public function evaluate($data){
              
            foreach($data as $key => $value){
                if(empty($value)){
                    
                    $this->error = $this->error . $key . "is empty !<br>" ;
                }
            }

            if($this->error == ""){

                //no error
                $this ->create_user($data);
            }else{
                return $this->error;
            }
        }
        
        public function create_user(){

            $usuario = $data['nome'];
            $email = $data['email'];
            $senha = $data['senha'];

            //create
            $url_adress = strtolower($usuario) . "." . strtolower($rmail);
            $user_id = create_userid(); 

            $query = "insert into user_signUp (user_id, nome, email, senha, url_adress) values ('$user_id','$usuario', '$email', '$senha', $url_adress)";
            //$DB = new Database();
           // $DB ->save($query);

           return $query;    
    }

    private function create_userid(){
        
        $lenght = round(4, 1);
        $number = "";
        for ($i=1; $i < $lenght; $i++) { 

            $new_random = round(0, 9);
            $number = $number . $new_random;
        }
        return $number;
    }
}
?>