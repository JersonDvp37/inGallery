<?php

     include("connection.php");
     include("SignsValidation.php");
    if($_SERVER['REQUEST_METHOD'] == 'POST'){

        $SignsValidation = new $SignsValidation();
        $result = $SignsValidation->evaluate($_POST);

        if($result != ""){
        echo $result;
        }

        //echo "<pre>";
       // print_r($_POST);
        //echo "</pre>";
    }
    


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signs</title>
    <link rel="stylesheet" href="SignsStyle.css">
     <script defer src="Signs.js"></script>
</head>
<body>
    <form action="Signs.php" method="post">
        <img src="MediaFiles/MozArt blue.png" alt="" class="logoMz">
    <div class="Box1">
        <div class="display" id="display">
            <label class="txtEntrar">Log in</label>
            <div class="icons">
                <a href=""><img src="MediaFiles/facebook (1).png" alt=""></a>
                <a href=""><img src="MediaFiles/pesquisa.png" alt="" class="iconGoogle"></a>

                <label for="" class="contaExistente">Acesse a tua conta exitente.</label>
            <ul class="icons-input">
                <img src="MediaFiles/o-email.png" alt="" class="email">
                <img src="MediaFiles/cadeado-trancado.png" alt="" class="cadeado">
            </ul>
                <ul class="inputs">
                   <input name="email" type="text" class="usEmail" id="usuMail" placeholder="Email ou usuario">
                   <input name="senha" type="password" class="password" id="passwords" placeholder="Senha" require>
                </ul>

                <a href=""><span class="recuperarSenha">Esqueceu a palavra-passe?</span></a>
                <input type="submit" class="btn_entrar">
            </div>  
        </div>


        <div class="displays2" id="displays2">
            <label class="txtEntrar2">Crie uma nova Conta</label>
            <div class="icons3">
                <a href=""><img src="MediaFiles/facebook (1).png" alt=""></a>
                <a href=""><img src="MediaFiles/pesquisa.png" alt="" class="iconGoogle"></a>

                <label for="" class="contaExistente2" id="advise-camp">Preencha os campos com precisao</label>
            <ul class="icons-input3">
                <img src="MediaFiles/do-utilizador - Cópia.png" alt="" class="2">
                <img src="MediaFiles/o-email.png" alt="" class="email2">
                <img src="MediaFiles/cadeado-trancado.png" alt="" class="cadeado2">
                <img src="MediaFiles/cadeado-trancado.png" alt="" class="cadeado3">
            </ul>
                <ul class="inputs3">
                   <input name="usuario" type="text" class="nome2" id="idnome" placeholder="Nome" required>
                   <input name="email" type="text" class="usEmail2" id="emsil-cadastro" placeholder="Email ou usuario" required>
                   <input name="senha" type="password" class="password2" id="senhaCadastro" placeholder="Senha" required>
                   <input name="Confirmar_senha" type="password" class="password3" id="senhaCadastro" placeholder="Confirmar senha" required>
                </ul>
                <input type="submit" class="btn_entrar3">
            </div>        
        </div>
</div>
 
        <div class="box_btn" id="darkBlueBox">
            <div class="darkBlue_content" id="darkBlue_content">
                <span class="titleBox">Bem-Vindo</span>
                <span class="signText">Cadastre-se agora, seja membro</span>
                <span class="btn_entrar4" onclick="toogle_Cadastro()">Cadastrar</span>
            </div>
            <div class="darkBlue_content2" id="darkBlue_content2">
                <span class="titleBox2">Bem-Vindo</span>
                <span class="signText2">Voce ja possue uma conta?
                    continue <br>conectado a nos.
                </span>
                <span class="btn_entrar2" id="btn_entrar2" onclick="toogle_Login()">Entrar</span>
            </div>

        </div>
                <li class="round-element00" id="round-blurElements" onclick="toogle_styleClick()"></li>
                <li class="round-element22" id="round-blurElements2" onclick="toogle_styleClick()"></li>
    </form>

</body>
</html>